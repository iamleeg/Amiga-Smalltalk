/*
    Copyright � 1995-2010, The AROS Development Team. All rights reserved.
    $Id$

    Desc: mx51.h
    Lang: english
*/

#ifndef ASM_ARM_MX51_H
#define ASM_ARM_MX51_H


#endif /* ASM_ARM_MX51_H */
