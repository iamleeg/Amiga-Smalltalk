#ifndef ASM_AARCH64_MMU_H
#define ASM_AARCH64_MMU_H

/*
    Copyright � 2016, The AROS Development Team. All rights reserved.
    $Id$
*/

#include <exec/types.h>
#include <inttypes.h>

#endif /* ASM_AARCH64_MMU_H */
