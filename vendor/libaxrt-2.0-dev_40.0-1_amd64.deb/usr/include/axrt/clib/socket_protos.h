#ifndef CLIB_SOCKET_PROTOS_H
#define CLIB_SOCKET_PROTOS_H

/*
    Copyright � 1995-2007, The AROS Development Team. All rights reserved.

    Desc: Wrapper for naming anomaly bsdsocket.library <-> socket.h
    Lang: English
*/

#include <clib/bsdsocket_protos.h>

#endif /* CLIB_SOCKET_PROTOS_H */
