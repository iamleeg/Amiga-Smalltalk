#ifndef CLIB_GAMEPORT_PROTOS_H
#define CLIB_GAMEPORT_PROTOS_H

/*
    *** Automatically generated from '/ssd/deadwood/repo-github-dd-alt-runtimelinux/AROS/rom/devs/gameport/gameport.conf'. Edits will be lost. ***
    Copyright � 1995-2020, The AROS Development Team. All rights reserved.
*/

#include <aros/libcall.h>

#include <exec/io.h>

__BEGIN_DECLS


#if !defined(__GAMEPORT_LIBAPI__) || (-2133978346 <= __GAMEPORT_LIBAPI__)
/* private */

#endif /* !defined(__GAMEPORT_LIBAPI__) || (-2133978346 <= __GAMEPORT_LIBAPI__) */

#if !defined(__GAMEPORT_LIBAPI__) || (278732085 <= __GAMEPORT_LIBAPI__)
/* private */

#endif /* !defined(__GAMEPORT_LIBAPI__) || (278732085 <= __GAMEPORT_LIBAPI__) */

__END_DECLS

#endif /* CLIB_GAMEPORT_PROTOS_H */
