#ifndef CLIB_WB_PROTOS_H
#define CLIB_WB_PROTOS_H

/*
    Copyright � 1995-2001, The AROS Development Team. All rights reserved.
    $Id$

    Desc: Wrapper for naming anomaly workbench.library <-> wb.h
    Lang: english
*/

#include <clib/workbench_protos.h>

#endif /* CLIB_WB_PROTOS_H */
