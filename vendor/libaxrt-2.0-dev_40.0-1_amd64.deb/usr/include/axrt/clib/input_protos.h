#ifndef CLIB_INPUT_PROTOS_H
#define CLIB_INPUT_PROTOS_H

/*
    *** Automatically generated from '/ssd/deadwood/repo-github-dd-alt-runtimelinux/AROS/rom/devs/input/input.conf'. Edits will be lost. ***
    Copyright � 1995-2020, The AROS Development Team. All rights reserved.
*/

#include <aros/libcall.h>


__BEGIN_DECLS


#if !defined(__INPUT_LIBAPI__) || (273959970 <= __INPUT_LIBAPI__)
/* private */

#endif /* !defined(__INPUT_LIBAPI__) || (273959970 <= __INPUT_LIBAPI__) */

#if !defined(__INPUT_LIBAPI__) || (-1878702526 <= __INPUT_LIBAPI__)
/* private */

#endif /* !defined(__INPUT_LIBAPI__) || (-1878702526 <= __INPUT_LIBAPI__) */

#if !defined(__INPUT_LIBAPI__) || (0 <= __INPUT_LIBAPI__)
AROS_LP0(UWORD, PeekQualifier,
         LIBBASETYPEPTR, InputBase, 7, Input
);

#endif /* !defined(__INPUT_LIBAPI__) || (0 <= __INPUT_LIBAPI__) */

__END_DECLS

#endif /* CLIB_INPUT_PROTOS_H */
