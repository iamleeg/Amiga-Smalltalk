#ifndef CLIB_BESTCOMM_PROTOS_H
#define CLIB_BESTCOMM_PROTOS_H

/*
    *** Automatically generated from '/ssd/deadwood/repo-github-dd-alt-runtimelinux/AROS/arch/ppc-chrp/efika/bestcomm/bestcomm.conf'. Edits will be lost. ***
    Copyright � 1995-2020, The AROS Development Team. All rights reserved.
*/

#include <aros/libcall.h>

#include <inttypes.h>

__BEGIN_DECLS


__END_DECLS

#endif /* CLIB_BESTCOMM_PROTOS_H */
