#ifndef DEFINES_ASYNCIO_H
#define DEFINES_ASYNCIO_H

/*
    *** Automatically generated from '/ssd/deadwood/repo-github-dd-alt-runtimelinux/AROS/contrib/workbench/libs/asyncio/src/asyncio.conf'. Edits will be lost. ***
    Copyright � 1995-2020, The AROS Development Team. All rights reserved.
*/

/*
    Desc: Defines for asyncio
*/

#include <aros/libcall.h>
#include <exec/types.h>
#include <aros/symbolsets.h>
#include <aros/preprocessor/variadic/cast2iptr.hpp>

#if !defined(__ASYNCIO_LIBBASE)
#    define __ASYNCIO_LIBBASE AsyncIOBase
#endif

__BEGIN_DECLS


#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __OpenAsync_WB(__AsyncIOBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC3(AsyncFile *, OpenAsync, \
                  AROS_LCA(const STRPTR,(__arg1),A0), \
                  AROS_LCA(OpenModes,(__arg2),D0), \
                  AROS_LCA(LONG,(__arg3),D1), \
        struct Library *, (__AsyncIOBase), 5, Asyncio);\
})

#define OpenAsync(arg1, arg2, arg3) \
    __OpenAsync_WB(__ASYNCIO_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __OpenAsyncFromFH_WB(__AsyncIOBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC3(AsyncFile *, OpenAsyncFromFH, \
                  AROS_LCA(BPTR,(__arg1),A0), \
                  AROS_LCA(OpenModes,(__arg2),D0), \
                  AROS_LCA(LONG,(__arg3),D1), \
        struct Library *, (__AsyncIOBase), 6, Asyncio);\
})

#define OpenAsyncFromFH(arg1, arg2, arg3) \
    __OpenAsyncFromFH_WB(__ASYNCIO_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __CloseAsync_WB(__AsyncIOBase, __arg1) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC1(LONG, CloseAsync, \
                  AROS_LCA(AsyncFile *,(__arg1),A0), \
        struct Library *, (__AsyncIOBase), 7, Asyncio);\
})

#define CloseAsync(arg1) \
    __CloseAsync_WB(__ASYNCIO_LIBBASE, (arg1))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __SeekAsync_WB(__AsyncIOBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC3(LONG, SeekAsync, \
                  AROS_LCA(AsyncFile *,(__arg1),A0), \
                  AROS_LCA(LONG,(__arg2),D0), \
                  AROS_LCA(SeekModes,(__arg3),D1), \
        struct Library *, (__AsyncIOBase), 8, Asyncio);\
})

#define SeekAsync(arg1, arg2, arg3) \
    __SeekAsync_WB(__ASYNCIO_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __ReadAsync_WB(__AsyncIOBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC3(LONG, ReadAsync, \
                  AROS_LCA(AsyncFile *,(__arg1),A0), \
                  AROS_LCA(APTR,(__arg2),A1), \
                  AROS_LCA(LONG,(__arg3),D0), \
        struct Library *, (__AsyncIOBase), 9, Asyncio);\
})

#define ReadAsync(arg1, arg2, arg3) \
    __ReadAsync_WB(__ASYNCIO_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __WriteAsync_WB(__AsyncIOBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC3(LONG, WriteAsync, \
                  AROS_LCA(AsyncFile *,(__arg1),A0), \
                  AROS_LCA(APTR,(__arg2),A1), \
                  AROS_LCA(LONG,(__arg3),D0), \
        struct Library *, (__AsyncIOBase), 10, Asyncio);\
})

#define WriteAsync(arg1, arg2, arg3) \
    __WriteAsync_WB(__ASYNCIO_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __ReadCharAsync_WB(__AsyncIOBase, __arg1) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC1(LONG, ReadCharAsync, \
                  AROS_LCA(AsyncFile *,(__arg1),A0), \
        struct Library *, (__AsyncIOBase), 11, Asyncio);\
})

#define ReadCharAsync(arg1) \
    __ReadCharAsync_WB(__ASYNCIO_LIBBASE, (arg1))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __WriteCharAsync_WB(__AsyncIOBase, __arg1, __arg2) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC2(LONG, WriteCharAsync, \
                  AROS_LCA(AsyncFile *,(__arg1),A0), \
                  AROS_LCA(UBYTE,(__arg2),D0), \
        struct Library *, (__AsyncIOBase), 12, Asyncio);\
})

#define WriteCharAsync(arg1, arg2) \
    __WriteCharAsync_WB(__ASYNCIO_LIBBASE, (arg1), (arg2))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __ReadLineAsync_WB(__AsyncIOBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC3(LONG, ReadLineAsync, \
                  AROS_LCA(AsyncFile *,(__arg1),A0), \
                  AROS_LCA(APTR,(__arg2),A1), \
                  AROS_LCA(LONG,(__arg3),D0), \
        struct Library *, (__AsyncIOBase), 13, Asyncio);\
})

#define ReadLineAsync(arg1, arg2, arg3) \
    __ReadLineAsync_WB(__ASYNCIO_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __WriteLineAsync_WB(__AsyncIOBase, __arg1, __arg2) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC2(LONG, WriteLineAsync, \
                  AROS_LCA(AsyncFile *,(__arg1),A0), \
                  AROS_LCA(STRPTR,(__arg2),A1), \
        struct Library *, (__AsyncIOBase), 14, Asyncio);\
})

#define WriteLineAsync(arg1, arg2) \
    __WriteLineAsync_WB(__ASYNCIO_LIBBASE, (arg1), (arg2))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __FGetsAsync_WB(__AsyncIOBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC3(APTR, FGetsAsync, \
                  AROS_LCA(AsyncFile *,(__arg1),A0), \
                  AROS_LCA(APTR,(__arg2),A1), \
                  AROS_LCA(LONG,(__arg3),D0), \
        struct Library *, (__AsyncIOBase), 15, Asyncio);\
})

#define FGetsAsync(arg1, arg2, arg3) \
    __FGetsAsync_WB(__ASYNCIO_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __FGetsLenAsync_WB(__AsyncIOBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC4(APTR, FGetsLenAsync, \
                  AROS_LCA(AsyncFile *,(__arg1),A0), \
                  AROS_LCA(APTR,(__arg2),A1), \
                  AROS_LCA(LONG,(__arg3),D0), \
                  AROS_LCA(LONG *,(__arg4),A2), \
        struct Library *, (__AsyncIOBase), 16, Asyncio);\
})

#define FGetsLenAsync(arg1, arg2, arg3, arg4) \
    __FGetsLenAsync_WB(__ASYNCIO_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

#if !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__)

#define __PeekAsync_WB(__AsyncIOBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(AsyncIOBase,40)\
        AROS_LC3(LONG, PeekAsync, \
                  AROS_LCA(AsyncFile *,(__arg1),A0), \
                  AROS_LCA(APTR,(__arg2),A1), \
                  AROS_LCA(LONG,(__arg3),D0), \
        struct Library *, (__AsyncIOBase), 17, Asyncio);\
})

#define PeekAsync(arg1, arg2, arg3) \
    __PeekAsync_WB(__ASYNCIO_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__ASYNCIO_LIBAPI__) || (40 <= __ASYNCIO_LIBAPI__) */

__END_DECLS

#endif /* DEFINES_ASYNCIO_H*/
