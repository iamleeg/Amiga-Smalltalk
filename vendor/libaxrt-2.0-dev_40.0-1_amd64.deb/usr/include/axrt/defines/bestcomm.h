#ifndef DEFINES_BESTCOMM_H
#define DEFINES_BESTCOMM_H

/*
    *** Automatically generated from '/ssd/deadwood/repo-github-dd-alt-runtimelinux/AROS/arch/ppc-chrp/efika/bestcomm/bestcomm.conf'. Edits will be lost. ***
    Copyright � 1995-2020, The AROS Development Team. All rights reserved.
*/

/*
    Desc: Defines for bestcomm
*/

#include <aros/libcall.h>
#include <exec/types.h>
#include <aros/symbolsets.h>
#include <aros/preprocessor/variadic/cast2iptr.hpp>

#if !defined(__BESTCOMM_LIBBASE)
#    define __BESTCOMM_LIBBASE BestCommBase
#endif

__BEGIN_DECLS


__END_DECLS

#endif /* DEFINES_BESTCOMM_H*/
