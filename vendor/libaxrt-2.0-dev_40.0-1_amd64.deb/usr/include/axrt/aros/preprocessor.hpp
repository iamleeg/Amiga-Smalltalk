# ifndef AROS_PREPROCESSOR_HPP
# define AROS_PREPROCESSOR_HPP
#
# include <boost/preprocessor.hpp>
#
# include <aros/preprocessor/array.hpp>
# include <aros/preprocessor/variadic.hpp>
#
# endif

