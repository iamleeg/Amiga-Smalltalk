# ifndef AROS_PREPROCESSOR_ARRAY_HPP
# define AROS_PREPROCESSOR_ARRAY_HPP
#
# include <aros/preprocessor/array/cast2iptr.hpp>
# include <aros/preprocessor/array/cast2tagitem.hpp>
#
# endif
